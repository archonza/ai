#The scalar input p is multiplied by the scalar weight w to form wp, one of the terms that is sent to the 
#summer. The other input, 1, is multiplied by a bias b and then passed to 
#the summer. The summer output n, often referred to as the net input, goes 
#into a transfer function f, which produces the scalar neuron output a. 
#(Some authors use the term “activation function” rather than transfer function and “offset” rather than bias.)

# p : scalar input
# w : scalar weight
# a : activation function or offset
# b : bias
# n : summer output or net input
# f : transfer function
# a = f(wp + b)
# Summer has 2 inputs, namely w*p and 1*b
# The summer output n, ofetn referred to as the net input, goes into a transfer function f, which producess the scalar neuron outpu a.
# Thus (p*w) + (1*b) = net input
# Let p  = 2
# Let w = 3
# Let b = -1.5
# Therefor
# a = f(p*w + 1*b)
# a = f(2*3 + 1*-1.5)
# a = f(6 -1.5)
# a = f(4.5)

#The actual output depends on the particular transfer function that is chosen
#bias is like a weight expect it has a constant input 1... bias can be ommited

#Three most popluar transfer functions:
# 1) Hard limit transfer function
# 2) Liniar tranfer function
# 3) Log Sigmoid tranfer function

# Scalar small italic letters
# Vectors small non italic bold letters
# Matrices capital Bold nonitalic letters

# Scalar 4
# Vector: 4,1
# Matrix: 1, 4, 3
#         2, 2, 4
#         9, 2, 4

# Imports
import sys
import os
from enum import Enum

class TransferFunctionType(Enum):
    HARD_LIMIT = 0
    LINEAR = 1
    LOG_SIGMOID = 2

class SingleInputNeuron:
    # Class variable
    p = 0.0
    w = 0.0
    b = 0.0
    netInput = 0.0
    hardLimitTransferFunctionResult = 0
    linearTransferFunctionResult = 0.0
    logSigmoidTransferFunctionResult = 0.0
    neuronOutput = 0.0

    #def  p(self, p: int):
    #    self.p = p
    def __init__(self) -> None:
        pass

    def calculateNetInput(self, input, weight, bias) ->  float:
        self.p = input
        self.w = weight
        self.b = bias
        self.netInput = (self.w * self.p) + (self.b * 1)
        return self.netInput

    def printNetInputFormula():
        print("(w*p) + (b*1)")

    def getNeuronOuput(self, fType : TransferFunctionType, netInput) -> float:
        if (fType == TransferFunctionType.HARD_LIMIT):
            self.neuronOutput = self.__hardLimitTransferFunction(netInput)
        elif (fType == TransferFunctionType.LINEAR):
            self.neuronOutput = self.__linearTransferFunction(netInput)
        elif (fType == TransferFunctionType.LOG_SIGMOID):
            self.neuronOutput = self.__logSigmoidTransferFunction(netInput)
        else:
            raise Exception("TransferFunctionType not defined")

        return self.neuronOutput

    def __hardLimitTransferFunction(self, netInput) -> int:
        if (netInput < 0.0):
            result = 0
        else:
            result = 1
        return result

    def __linearTransferFunction(self, netInput) -> float:
        return 0.0

    def __logSigmoidTransferFunction(self, netInput) -> float:
        return 0.0



singleInputNeuron = SingleInputNeuron()
#netInput = singleInputNeuron.calculateNetInput(2, 3 , -1.5)
#print("netInput: {:.2f}".format(netInput))
#neuronOutput = singleInputNeuron.getNeuronOuput(TransferFunctionType.HARD_LIMIT, netInput)
#print("neuronOutput: {:.2f}".format(neuronOutput))
shouldIGoSurf = 0
# input1... the current wave size
waveSize = 1.0
# input2... the weight... what weight does input1 have
# input1's weight or importance is determined by the size of the wave vs what size is a wave that is optimal
#optimalSize = 3.0
#weight = waveSize/optimalSize
# The bias here lets the transfer function know about my preference in size of wave
bias = -100.0
for input in range(110):
    optimalSize = 100.0
    weight = input/optimalSize
    netInput = singleInputNeuron.calculateNetInput(input, weight , bias)
    neuronOutput = singleInputNeuron.getNeuronOuput(TransferFunctionType.HARD_LIMIT, netInput)
    print("neuronOutput: {:.2f}".format(neuronOutput))

